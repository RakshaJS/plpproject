import React, { Component } from "react";

import Modal from "./components/Modal";

class App extends Component {
  constructor() {
    super();

    this.state = {
      isShowing: false
    };
  }

  openModalHandler = () => {
    this.setState({
      isShowing: true
    });
  };

  closeModalHandler = () => {
    this.setState({
      isShowing: false
    });
  };

  render() {
    return (
      <div>
        {this.state.isShowing ? (
          <div onClick={this.closeModalHandler} className="back-drop" />
        ) : null}

        <button className="open-modal-btn" onClick={this.openModalHandler}>
          Open Modal
        </button>

        <Modal
          className="modal"
          show={this.state.isShowing}
          close={this.closeModalHandler}
        >
          <textarea cols="95" rows="6">
            Maybe aircrafts fly very high because they don't want to be seen in
            plane sight?
          </textarea>
        </Modal>
      </div>
    );
  }
}

export default App;

// import React, { Component } from "react";
// //import logo from "./logo.svg";
// import "./App.css";
// import Navbar from "./components/Navbar";
// import Register from "./components/Signup";
// import Login from "./components/Login";
// import Home from "./components/Home";
// import userget from "./components/userget";

// import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
// import Demo from "./components/Demo";
// import Cards from "./components/Cards";
// import Demo2 from "./components/Demo2";
// import CreateRoom from "./components/CreateRoom";
// import { Dashboard } from "./components/Dashboard";
// import NavigateFrom from "./components/NavigateFrom";
// class App extends Component {
//   render() {
//     return (
//       <Router>
//         <div className="container">
//           <Navbar />
//           <Switch>
//             <Route exact path="/" component={Home} />
//             <Route exact path="/login" component={Login} />
//             <Route exact path="/signup" component={Register} />
//             <Route exact path="/userget" component={userget} />
//             <Route exact path="/Demo" component={Demo} />
//             <Route exact path="/Demo2" component={Demo2} />
//             <Route exact path="/CreateRoom" component={CreateRoom} />
//             <Route exact path="/Dashboard" component={Dashboard} />
//             <Route exact path="/NavigateFrom" component={NavigateFrom} />

//             <Route exact path="/Cards" component={Cards} />
//           </Switch>
//         </div>
//       </Router>
//     );
//   }
// }

// export default App;
