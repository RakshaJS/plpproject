import React from "react";
import { Link } from "react-router-dom";
import Card from "react-bootstrap/Card";
import { Button, ListGroup } from "react-bootstrap";

export class Cards extends React.Component {
 
  render() {
    return (
      <div className="text-center">
        <div className="col-lg-4 " />
        <div className="col-lg-2">
          <h1> hi </h1>
          <input type="text" />
          <button
            type="button"
            className="btn btn-success"
            onClick="OnChange()"
          >
            Save
          </button>
          <div className="container">
            <Card style={{ border: "4px solid black", width: "40rem" }}>
              <div className="image">
                <img
                  className="img-circle"
                  src={require("../components/images/img.jpg")}
                />
              </div>
              <Card.Body>
                <Card.Title className="text-center">
                  <b>Welcome</b>
                </Card.Title>
                <Card.Subtitle className="mb-2 text-muted text-center">
                  Computer Science Enginner
                </Card.Subtitle>
                <ListGroup variant="flush">
                  <ListGroup.Item>
                    <Link to="/connections">
                      {" "}
                      Connections &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                      <b className="text-right">160</b>
                    </Link>
                  </ListGroup.Item>
                </ListGroup>
              </Card.Body>
            </Card>
            ;
          </div>
        </div>
      </div>
    );
  }
}

export default Cards;
