import React from 'react';
class userget extends React.Component{
    render(){
        return(
            <div>
                <h1>Hi</h1>
                </div>
        )
    }
}

export default userget;