import React from "react";
import { Redirect } from "react-router";
import axios from "axios";
class Signup extends React.Component {
  constructor() {
    super();
    this.state = {
      fields: {},
      errors: {},
      redirect: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.submituserRegistrationForm = this.submituserRegistrationForm.bind(
      this
    );
  }

  handleChange(e) {
    let fields = this.state.fields;
    fields[e.target.name] = e.target.value;
    this.setState({
      fields
    });
  }
  routeChange(id) {
    let path = `/login`;
    this.props.history.push(path);
  }
  submituserRegistrationForm(e) {
    e.preventDefault();
    if (this.validateForm()) {
      let fields = {};
      fields["Firstname"] = this.state.Firstname;
      fields["Lastname"] = this.state.Lastname;
      fields["EmailId"] = this.state.EmailId;
      fields["Password"] = this.state.Password;
      this.setState({ fields: fields });
      alert("Form submitted");
      axios
        .post("http://localhost:3001/signup", fields)
        .then(function(response) {
          console.log(response.data);
        });
      this.setState({
        name: "",
        status: "",
        redirect: true
      });
    }
  }

  validateForm() {
    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;

    if (!fields["Firstname"]) {
      formIsValid = false;
      errors["Firstname"] = "*Please enter your firstname.";
    }

    if (typeof fields["Firstname"] !== "undefined") {
      if (!fields["Firstname"].match(/^[a-zA-Z ]*$/)) {
        formIsValid = false;
        errors["Firstname"] = "*Please enter alphabet characters only.";
      }
    }
    if (!fields["Lastname"]) {
      formIsValid = false;
      errors["Lastname"] = "*Please enter your Last name.";
    }

    if (typeof fields["Lastname"] !== "undefined") {
      if (!fields["Lastname"].match(/^[a-zA-Z ]*$/)) {
        formIsValid = false;
        errors["Lastname"] = "*Please enter alphabet characters only.";
      }
    }

    if (!fields["EmailId"]) {
      formIsValid = false;
      errors["EmailId"] = "*Please enter your email-ID.";
    }

    if (typeof fields["EmailId"] !== "undefined") {
      //regular expression for email validation
      var pattern = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern.test(fields["EmailId"])) {
        formIsValid = false;
        errors["EmailId"] = "*Please enter valid email-ID.";
      }
    }

    if (!fields["Password"]) {
      formIsValid = false;
      errors["Password"] = "*Please enter your password.";
    }

    if (typeof fields["Password"] !== "undefined") {
      if (
        !fields["Password"].match(
          /^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/
        )
      ) {
        formIsValid = false;
        errors["Password"] = "*Please enter secure and strong password.";
      }
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }

  render() {
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    if (redirect) {
      return <Redirect to="/login" />;
    }
    return (
      <div id="main-registration-container">
        <div id="register">
          <h3>Registration page</h3>
          <form
            method="post"
            name="userRegistrationForm"
            onSubmit={this.submituserRegistrationForm}
          >
            <label>FirstName</label>
            <input
              type="text"
              name="Firstname"
              value={this.state.fields.Firstname}
              onChange={this.handleChange}
            />
            <div className="errorMsg">{this.state.errors.Firstname}</div>
            <label>Lastname Name:</label>
            <input
              type="text"
              name="Lastname"
              value={this.state.fields.Lastname}
              onChange={this.handleChange}
            />
            <div className="errorMsg">{this.state.errors.Lastname}</div>
            <label>Email ID:</label>
            <input
              type="text"
              name="EmailId"
              value={this.state.fields.EmailId}
              onChange={this.handleChange}
            />
            <div className="errorMsg">{this.state.errors.EmailId}</div>

            <label>Password</label>
            <input
              type="password"
              name="Password"
              value={this.state.fields.Password}
              onChange={this.handleChange}
            />
            <div className="errorMsg">{this.state.errors.Password}</div>
            <input type="submit" className="btn btn-success" value="Register" />
          </form>
        </div>
      </div>
    );
  }
}

export default Signup;

// import React from "react";
// import axios from "axios";
// import { Redirect } from "react-router";
// class Signup extends React.Component {
//   constructor(props) {
//     super(props);
//     this.routeChange = this.routeChange.bind(this);
//     this.onChangeFirstname = this.onChangeFirstname.bind(this);
//     this.onChangeLastname = this.onChangeLastname.bind(this);
//     this.onChangeEmail = this.onChangeEmail.bind(this);
//     this.onChangePassword = this.onChangePassword.bind(this);
//     this.onSubmit = this.onSubmit.bind(this);
//     this.state = {
//       Firstname: "",
//       Lastname: "",
//       Email: "",
//       Password: "",
//       redirect: false
//     };
//   }

//   onChangeFirstname(e) {
//     this.setState({
//       Firstname: e.target.value
//     });
//   }

//   onChangeLastname(e) {
//     this.setState({
//       Lastname: e.target.value
//     });
//   }
//   onChangeEmail(e) {
//     this.setState({
//       Email: e.target.value
//     });
//   }

//   onChangePassword(e) {
//     this.setState({
//       Password: e.target.value
//     });
//   }

//   routeChange(id) {
//     let path = `/login`;
//     this.props.history.push(path);
//   }
//   onSubmit(e) {
//     e.preventDefault();
//     const signup = {
//       Firstname: this.state.Firstname,
//       Lastname: this.state.Lastname,
//       Email: this.state.Email,
//       Password: this.state.Password
//     };
//     console.log(signup);
//     axios.post("http://localhost:3001/signup", signup).then(function(response) {
//       console.log(response.data);
//     });
//     this.setState({
//       name: "",
//       status: "",
//       redirect: true
//     });
//   }
//   render() {
//     const { redirect } = this.state;
//     console.log("redirect value" + redirect);
//     if (redirect) {
//       return <Redirect to="/login" />;
//     }
//     return (
//       <div>
//         <h1> Signup Component</h1>
//         <form onSubmit={this.onSubmit}>
//           <div className="form-group">
//             <label> First Name:</label>
//             <input
//               type="text"
//               className="form-control"
//               value={this.state.Firstname}
//               onChange={this.onChangeFirstname}
//             />
//           </div>
//           <div className="form-group">
//             <label> Last Name: </label>
//             <input
//               type="text"
//               className="form-control"
//               value={this.state.Lastname}
//               onChange={this.onChangeLastname}
//             />
//           </div>
//           <div className="form-group">
//             <label> Email :</label>
//             <input
//               type="email"
//               className="form-control"
//               value={this.state.Email}
//               onChange={this.onChangeEmail}
//             />
//           </div>
//           <div className="form-group">
//             <label> Password: </label>
//             <input
//               type="password"
//               className="form-control"
//               value={this.state.Password}
//               onChange={this.onChangePassword}
//             />
//           </div>
//           <div className="form-group">
//             <input type="submit" value="Signup" className="btn btn-primary" />
//           </div>
//         </form>
//       </div>
//     );
//   }
// }
// export default Signup;
